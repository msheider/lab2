/*
 * Dog.cpp
 *
 *  Created on: Feb 14, 2023
 *      Authors: Jordan Watson && Melony Heider
 */

#include "Dog.hpp"
#include "Board.hpp"
#include <iostream>
#include <string.h>
using namespace std;

Dog::Dog(string n){ //"Dog constructor for string n (to use the name)"
	strength = 50;	//Strength initalized as 50. (Could be anything else. Try changing the value!)
	name = n;		//name: Dog's name
	x = 0;			//x & y: Coordinates of where Boomer is placed.
	y = 0;
}

Dog::Dog(){			//"Dog Constructor"
	strength = 50;	//Same thing as the constructor above.
	name = "Boomer";//Boomer: My dog. (Though i could've added a character selector...)
	x = 0;
	y = 0;
}

bool Dog::changeStrength(int amt){
/* Boolean function that changes the amount of strength of the dog has.
 * This function checks for the amount of strength the dog has and
 * whether or not they have strength. Calls the die(); function
 * if the strength is 0 or less.
 */
	strength += amt;
	if (strength > 0){
		return true;
	}
	else{
		return false;
		die();
	}
}

void Dog::die(){ //lose message when the dog has no strength left.
	if (strength <= 0){
		cout << "Boomer has no strength left and has died..." << endl;
		cout << "Consider yourself a darkner." << endl;
	}
}

void Dog::printDog(){
//This is just printing the dog information. Nothing too major.
	cout << name << endl;
	cout << strength << endl;
	cout << x << endl;
	cout << y << endl;
}

void Dog::won(){ //won message for when dog is at end of evil forest
	cout << "You win! Boomer has found the exit to get home!" << endl;
	cout << "Consider yourself a lightner!" << endl;
}

void Dog::reset(){
	strength = 50;
	name = "Boomer";
	x = 0;
	y = 0;
}
