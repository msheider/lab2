/*
 * mainGame.cpp
 *
 *  Created on: Feb 14, 2023
 *      Authors: Jordan Watson && Melony Heider
 */

#include "Board.hpp"
#include <iostream>
#include <time.h>
#include <stdlib.h>
using namespace std;


int main() {
	srand(time(NULL));
	Board board('m',"fido", true);
	return 0;
}
