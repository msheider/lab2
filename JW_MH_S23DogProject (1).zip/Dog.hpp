/*
 * Dog.hpp
 *
 *  Created on: Feb 14, 2023
 *      Authors: Jordan Watson && Melony Heider
 */

#ifndef DOG_HPP_
#define DOG_HPP_
#include <iostream>
#include <string.h>
using namespace std;
class Dog{

	friend class Board;
	friend class Game;
	int strength;
	string name;
	int x;
	int y;

public:
	Dog(string n); //Constructor
	Dog(); //Constructor
	bool changeStrength(int amt); //Dog�s strength field adjuster
	void die(); //Prints lose message
	void printDog(); // Prints dog info
	void won(); //Prints win message
	void reset(); //New Game reset
};
#endif /* DOG_HPP_ */
